#ifndef DIFFUSION
#define DIFFUSION

void diffusion(double spec_prob, double theta_in, double phi_in, double *theta_out, double *phi_out);

#endif
