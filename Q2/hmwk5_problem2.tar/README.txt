diffusion.c is the c function source file

diffusion.h is the head file of the source file

Makefile help compile the c function file and head file to produce the required shared library "libhmwk5p2.so"

By entering the syntax of "python Python_call.py" in the command line of Linux system, the Python_call.py is successfully running and produce 2 data files:
hmwk5_problem2a.dat and hmwk5_problem2b.dat 

The file of "plot.gnu" is used to read the data files and produce plots

Compared to the pure C or Python program, it takes 6 secs to execute 10e6 times loop
