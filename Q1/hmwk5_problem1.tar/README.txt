diffusion.c is the c function source file

diffusion.h is the head file of the source file

Makefile help compile the c function file and head file to produce the executable file C_call

By entering the syntax of "C_call" in the command line of Linux system, it is successfully running and produce 2 data files:
hmwk5c_problem1a.dat and hmwk5c_problem1b.dat 

The file of "plot.gnu" is used to read the data files and produce plots

For the C program, it only takes less than 0.5 secs to execute 10e6 times loop.
